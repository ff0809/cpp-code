/******************************************************************
* ��ע�⣡                                                         *
* ��ͷ�ļ���Ϊ���װ��WinAPI��WIC�ײ㺯�������������ͼƬ��ȡ��������  *
* ���װ�������ⲿ�⣬����������һ����Լ��������������ϸ�Ķ����¹涨  *
*     ��ͷ�ļ����κ�û��TO-DO�ĵط����㲻Ҫ�޸ģ��������������⣬      *
* �뼰ʱ��ϵ��ʦ�����̣�                                            *
*     ÿһ��TO-DO����TO-DO��˵�� (TO-DO) END ����������ɿ��·�����  *
*     readPic()����Ϊ���װ��WinAPI�еķ��������Խ�ͼƬ��ȡΪRGBA��   *
* bitmap���ݣ����Ⲣ�����������ͨ���޸��������ֱ�Ӵﵽ��ȡ�Ҷ�ͼ��   *
* Ŀ�ġ�                                                           *
*     getData()����������Ҫ���Ƶĺ���������ȡ������һάBYTE����ת��   *
* ����ʵ�ֵ�Array�ࡣ                                              *
*     testReader()��demo���ṩ��ȡ���ݵ�����һ��˼·��               *
******************************************************************/
#ifndef PIC_READER_H
#define PIC_READER_H

#include <windows.h>
#include <wincodec.h>
#include <commdlg.h>
#include <vector>
#include <string>
#include "Array.h"

template <typename T>
inline void SafeRelease(T*& p) {
	if (nullptr != p) {
		p->Release();
		p = nullptr;
	}
}

class PicReader {
public:
	PicReader();
	~PicReader();

	bool readPic(LPCSTR fileName);
	bool readPic(const std::string& fileName);

	Array getData(bool asGrayScale = false);
	Array getData(int x, int y, int width, int height, bool asGrayScale = false);

	void testReader(BYTE*&, UINT&, UINT&);

	UINT getWidth() const { return imageWidth; }
	UINT getHeight() const { return imageHeight; }
	bool isLoaded() const { return m_pConvertedSourceBitmap != nullptr; }

private:
	void init();
	bool checkHR(HRESULT);
	void quitWithError(LPCSTR);
	bool copyBitmapData(BYTE*& data, UINT& x, UINT& y);

	HWND                    hWnd;
	HANDLE                  hFile;
	IWICImagingFactory* m_pIWICFactory;
	IWICFormatConverter* m_pConvertedSourceBitmap;
	UINT                   imageWidth;
	UINT                   imageHeight;

	/*TO-DO��������ܻ���������Ҫ���ڲ���Ա END*/
};

PicReader::PicReader() : m_pConvertedSourceBitmap(nullptr), m_pIWICFactory(nullptr),
imageWidth(0), imageHeight(0), hFile(NULL) {
	init();
}

PicReader::~PicReader() {
	if (hFile != NULL && hFile != INVALID_HANDLE_VALUE)
		CloseHandle(hFile);
	SafeRelease(m_pConvertedSourceBitmap);
	SafeRelease(m_pIWICFactory);
	CoUninitialize();
}

bool PicReader::checkHR(HRESULT hr) {
	return FAILED(hr);
}

void PicReader::quitWithError(LPCSTR message) {
	MessageBoxA(hWnd, message, "Application Error", MB_ICONEXCLAMATION | MB_OK);
	quick_exit(0xffffffff);
}

void PicReader::init() {
	hWnd = GetForegroundWindow();

	HeapSetInformation(nullptr, HeapEnableTerminationOnCorruption, nullptr, 0);

	HRESULT hr = S_OK;

	hr = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);

	hr = CoCreateInstance(
		CLSID_WICImagingFactory,
		nullptr,
		CLSCTX_INPROC_SERVER,
		IID_PPV_ARGS(&m_pIWICFactory)
	);

	if (checkHR(hr)) { quitWithError("Init Reader Failed"); }
}

bool PicReader::readPic(LPCSTR fileName) {
	HRESULT hr = S_OK;

	SafeRelease(m_pConvertedSourceBitmap);
	imageWidth = 0;
	imageHeight = 0;

	if (hFile != NULL && hFile != INVALID_HANDLE_VALUE) {
		CloseHandle(hFile);
		hFile = NULL;
	}

	hFile = CreateFileA(fileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		DWORD error = GetLastError();
		if (error == ERROR_FILE_NOT_FOUND) {
			quitWithError("Cannot find such file, please retry or check the access");
		}
		else {
			char errorMsg[256];
			sprintf_s(errorMsg, "Cannot open file. Error code: %lu", error);
			quitWithError(errorMsg);
		}
		return false;
	}

	IWICBitmapDecoder* pDecoder = nullptr;
	hr = m_pIWICFactory->CreateDecoderFromFileHandle((ULONG_PTR)hFile, nullptr, WICDecodeMetadataCacheOnDemand, &pDecoder);
	if (checkHR(hr)) {
		CloseHandle(hFile);
		hFile = NULL;
		quitWithError("Create Decoder Failed");
		return false;
	}

	IWICBitmapFrameDecode* pFrame = nullptr;
	hr = pDecoder->GetFrame(0, &pFrame);
	if (checkHR(hr)) {
		SafeRelease(pDecoder);
		CloseHandle(hFile);
		hFile = NULL;
		quitWithError("Get Frame Failed");
		return false;
	}

	hr = m_pIWICFactory->CreateFormatConverter(&m_pConvertedSourceBitmap);
	if (checkHR(hr)) {
		SafeRelease(pFrame);
		SafeRelease(pDecoder);
		CloseHandle(hFile);
		hFile = NULL;
		quitWithError("Get Format Converter Failed");
		return false;
	}

	hr = m_pConvertedSourceBitmap->Initialize(pFrame, GUID_WICPixelFormat32bppRGBA, WICBitmapDitherTypeNone, nullptr, 0.f, WICBitmapPaletteTypeCustom);
	if (checkHR(hr)) {
		SafeRelease(m_pConvertedSourceBitmap);
		SafeRelease(pFrame);
		SafeRelease(pDecoder);
		CloseHandle(hFile);
		hFile = NULL;
		quitWithError("Init Bitmap Failed");
		return false;
	}

	hr = m_pConvertedSourceBitmap->GetSize(&imageWidth, &imageHeight);
	if (checkHR(hr)) {
		SafeRelease(m_pConvertedSourceBitmap);
		SafeRelease(pFrame);
		SafeRelease(pDecoder);
		CloseHandle(hFile);
		hFile = NULL;
		quitWithError("Get Image Size Failed");
		return false;
	}

	SafeRelease(pDecoder);
	SafeRelease(pFrame);

	return true;
}

bool PicReader::readPic(const std::string& fileName) {
	return readPic(fileName.c_str());
}

bool PicReader::copyBitmapData(BYTE*& data, UINT& x, UINT& y) {
	if (!m_pConvertedSourceBitmap) {
		return false;
	}

	HRESULT hr = S_OK;

	hr = m_pConvertedSourceBitmap->GetSize(&x, &y);
	if (checkHR(hr)) {
		quitWithError("Check Bitmap Size Failed");
		return false;
	}

	data = new BYTE[x * y * 4];
	memset(data, 0, x * y * 4);

	UINT stride = x * 4;
	hr = m_pConvertedSourceBitmap->CopyPixels(nullptr, stride, x * y * 4, data);
	if (checkHR(hr)) {
		delete[] data;
		data = nullptr;
		quitWithError("Copy Pixels Failed");
		return false;
	}

	return true;
}

Array PicReader::getData(bool asGrayScale) {
	if (!m_pConvertedSourceBitmap) {
		throw std::runtime_error("No image loaded. Call readPic() first.");
	}

	BYTE* data = nullptr;
	UINT x = 0, y = 0;

	if (!copyBitmapData(data, x, y)) {
		throw std::runtime_error("Failed to copy bitmap data");
	}

	/******************************************************************
	*  TO-DO:                                                         *
	*                                                                 *
	*  ʵ��һ��Array�࣬���������dataת�������Array��                  *
	*                                                                 *
	*  ����˵������Bitmap Copy���������ݣ�ÿ4��Ϊһ�����һ������         *
	*           ����Ϊһ������Ϊͼ���(��*��*4)��һά����                *
	*           �������Ų�Ϊ R G B A R G B A R G B A.....              *
	*                                                                 *
	*  ��ע�⣡  �������ֻ�Ķ��Ӵ˿�ʼ����һ��TO-DO ENDλ�õĴ��룡       *
	******************************************************************/

	// 1. ����Array���󣬴�СΪx*y*4
	Array result(x, y, 4);

	// 2. ��BYTE���ݸ��Ƶ�Array��
	for (UINT i = 0; i < y; i++) {
		for (UINT j = 0; j < x; j++) {
			UINT dataIndex = (i * x + j) * 4;
			for (int k = 0; k < 4; k++) {
				result.at(j, i, k) = static_cast<int>(data[dataIndex + k]);
			}
		}
	}

	// 3. �����Ҫ�Ҷ�ͼ��ת��Ϊ��ͨ��
	if (asGrayScale) {
		Array grayResult(x, y, 1);
		for (UINT i = 0; i < y; i++) {
			for (UINT j = 0; j < x; j++) {
				int r = result.at(j, i, 0);
				int g = result.at(j, i, 1);
				int b = result.at(j, i, 2);
				// ʹ�ñ�׼�Ҷ�ת����ʽ
				int gray = (r * 299 + g * 587 + b * 114 + 500) / 1000;
				grayResult.at2D(j, i) = gray;
			}
		}
		delete[] data;
		return grayResult;
	}

	// 4. ɾ����ʱ����
	delete[] data;

	/******************************************************************
	*  TO-DO END                                                      *
	******************************************************************/

	if (hFile != NULL && hFile != INVALID_HANDLE_VALUE) {
		CloseHandle(hFile);
		hFile = NULL;
	}

	return result;
}

Array PicReader::getData(int startX, int startY, int width, int height, bool asGrayScale) {
	if (!m_pConvertedSourceBitmap) {
		throw std::runtime_error("No image loaded. Call readPic() first.");
	}

	if (startX < 0 || startY < 0 || width <= 0 || height <= 0 ||
		startX + width >(int)imageWidth || startY + height >(int)imageHeight) {
		throw std::out_of_range("Invalid subimage coordinates");
	}

	Array fullImage = getData(asGrayScale);

	if (asGrayScale) {
		Array subImage(width, height, 1);
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				subImage.at2D(x, y) = fullImage.at2D(startX + x, startY + y);
			}
		}
		return subImage;
	}
	else {
		Array subImage(width, height, 4);
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				for (int c = 0; c < 4; c++) {
					subImage.at(x, y, c) = fullImage.at(startX + x, startY + y, c);
				}
			}
		}
		return subImage;
	}
}

void PicReader::testReader(BYTE*& _out, UINT& _x, UINT& _y) {
	if (!m_pConvertedSourceBitmap) {
		throw std::runtime_error("No image loaded. Call readPic() first.");
	}

	if (!copyBitmapData(_out, _x, _y)) {
		throw std::runtime_error("Failed to copy bitmap data");
	}

	if (hFile != NULL && hFile != INVALID_HANDLE_VALUE) {
		CloseHandle(hFile);
		hFile = NULL;
	}
}

#endif