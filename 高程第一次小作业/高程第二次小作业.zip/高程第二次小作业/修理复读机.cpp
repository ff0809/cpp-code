//#include<iostream>
//#include<fstream>
//using namespace std;
//
//int main()
//{
//	ifstream in;
//	in.open("C:\\Users\\LENOVO\\Desktop\\noise.txt", ios::in);
//	if (!in.is_open())
//	{
//		cerr << "�ļ���ʧ�ܣ�" << endl;
//	}
//	char ch;
//	int pos = 0;
//	while (in.get(ch))
//	{
//		pos++;
//		if (pos % 3 == 1)
//		{
//			cout << ch;
//		}
//	}
//	return 0;
//}