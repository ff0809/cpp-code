#include "game.h"

// ��ʼ����Ϸ
void Game::init()
{
    initgraph(WIDTH, HEIGHT);
    setbkcolor(WHITE);
    loadimage(&backgroundImg, _T("jidi.jpg")); // ���ر���ͼƬ
}

// ������Ϸ��ѭ��
void Game::run()
{
    BeginBatchDraw();//����˫�����ͼģʽ��������˸

    while (true)
    {
        cleardevice();
        drawBackground();//����Ϸ��ʼǰ���Ʊ���

        switch (currentState)
        {
        case MENU:
            showMainMenu();
            break;
        case MODE_SELECTION:
            showModeSelection();
            break;
        case PLAYING:
            playGame();
            break;
        case SHOWING_RULES:
            showRules();
            break;
        case GAME_OVER:
            showGameOver();
            break;
        }

        FlushBatchDraw();// ˢ����Ļ
        handleMouseInput();
        Sleep(1);// ����CPUռ��
    }

    EndBatchDraw();// ����˫����
}

// �����������
void Game::handleMouseInput()
{
    if (MouseHit())
    {
        MOUSEMSG msg = GetMouseMsg();// ��ȡ�����Ϣ

        if (msg.uMsg == WM_MOUSEMOVE)// ����ƶ��¼�
        {
            hoveredOption = NONE;

            if (currentState == MENU)
            {
                if (PtInRect(&startButton, msg.x, msg.y)) hoveredOption = CLASSIC_MODE;//PtInRect����������λ���Ƿ��ھ�����
                else if (PtInRect(&rulesButton, msg.x, msg.y)) hoveredOption = GAME_RULES;
                else if (PtInRect(&exitButton, msg.x, msg.y)) hoveredOption = EXIT_GAME;
            }
            else if (currentState == MODE_SELECTION)
            {
                if (PtInRect(&classicButton, msg.x, msg.y)) hoveredOption = CLASSIC_MODE;
                else if (PtInRect(&challengeButton, msg.x, msg.y)) hoveredOption = CHALLENGE_MODE;
                else if (PtInRect(&backButton, msg.x, msg.y)) hoveredOption = EXIT_GAME;
            }
        }

        if (msg.uMsg == WM_LBUTTONDOWN) // �����������¼�
        {
            switch (currentState)
            {
            case MENU:
                if (PtInRect(&startButton, msg.x, msg.y))
                {
                    currentState = MODE_SELECTION;
                }
                else if (PtInRect(&rulesButton, msg.x, msg.y))
                {
                    currentState = SHOWING_RULES;
                }
                else if (PtInRect(&exitButton, msg.x, msg.y))
                {
                    closegraph();
                    exit(0);
                }
                break;

            case MODE_SELECTION:
                if (PtInRect(&classicButton, msg.x, msg.y))
                {
                    board.reset(CLASSIC);
                    currentState = PLAYING;
                }
                else if (PtInRect(&challengeButton, msg.x, msg.y))
                {
                    showChallengeSelection();
                }
                else if (PtInRect(&backButton, msg.x, msg.y))
                {
                    currentState = MENU;
                }
                break;

            case PLAYING:
                if (PtInRect(&restartButtonInGame, msg.x, msg.y))
                {
                    board.reset(board.getCurrentMode());
                }
                else if (PtInRect(&undoButtonInGame, msg.x, msg.y))
                {
                    board.undoMove();
                }
                else if (PtInRect(&hintButtonInGame, msg.x, msg.y))
                {
                    board.toggleHint();
                }
                else if (PtInRect(&backButtonInGame, msg.x, msg.y))
                {
                    currentState = MENU;
                }
                else
                {
                    board.selectOrMove(msg.x, msg.y);

                    if (board.isWin() || board.isLose())
                    {
                        currentState = GAME_OVER;
                    }
                }
                break;

            case SHOWING_RULES:
                currentState = MENU;
                break;

            case GAME_OVER:
                if (PtInRect(&restartButton, msg.x, msg.y))
                {
                    board.reset(board.getCurrentMode());
                    currentState = PLAYING;
                }
                else if (PtInRect(&menuButton, msg.x, msg.y))
                {
                    currentState = MENU;
                }
                break;
            }
        }
    }
}

// ��ʾ�о�ѡ�����
void Game::showChallengeSelection()
{
    cleardevice();
    drawBackground();//��ѡ��о�ʱҲ���Ƶ���ͼƬ����

    // ���Ʊ���
    settextstyle(36, 0, _T("����"), 0, 0, FW_BOLD, false, false, false);
    settextcolor(RGB(70, 130, 180));
    outtextxy(WIDTH / 2 - 100, 150, _T("ѡ��о�"));

    // ���Ʋо�ѡ��
    settextstyle(28, 0, _T("����"));

    // �о�1��ť
    setfillcolor(RGB(180, 230, 100));
    fillrectangle(challenge1Button.left, challenge1Button.top, challenge1Button.right, challenge1Button.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(challenge1Button.left + 30, challenge1Button.top + 20, _T("�о�1"));

    // �о�2��ť
    setfillcolor(RGB(100, 180, 255));
    fillrectangle(challenge2Button.left, challenge2Button.top, challenge2Button.right, challenge2Button.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(challenge2Button.left + 30, challenge2Button.top + 20, _T("�о�2"));

    // �о�3��ť
    setfillcolor(RGB(255, 200, 100));
    fillrectangle(challenge3Button.left, challenge3Button.top, challenge3Button.right, challenge3Button.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(challenge3Button.left + 30, challenge3Button.top + 20, _T("�о�3"));

    // �о�4��ť
    setfillcolor(RGB(255, 150, 200));
    fillrectangle(challenge4Button.left, challenge4Button.top, challenge4Button.right, challenge4Button.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(challenge4Button.left + 30, challenge4Button.top + 20, _T("�о�4"));

    // ���ذ�ť
    setfillcolor(RGB(200, 200, 200));
    fillrectangle(backToModeButton.left, backToModeButton.top, backToModeButton.right, backToModeButton.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(backToModeButton.left + 30, backToModeButton.top + 20, _T("����"));

    FlushBatchDraw();// ˢ����Ļ

    // �����о�ѡ��
    while (true)
    {
        if (MouseHit())
        {
            MOUSEMSG msg = GetMouseMsg();
            if (msg.uMsg == WM_LBUTTONDOWN)
            {
                if (PtInRect(&challenge1Button, msg.x, msg.y))
                {
                    board.reset(CHALLENGE_1);
                    currentState = PLAYING;
                    return;
                }
                else if (PtInRect(&challenge2Button, msg.x, msg.y))
                {
                    board.reset(CHALLENGE_2);
                    currentState = PLAYING;
                    return;
                }
                else if (PtInRect(&challenge3Button, msg.x, msg.y))
                {
                    board.reset(CHALLENGE_3);
                    currentState = PLAYING;
                    return;
                }
                else if (PtInRect(&challenge4Button, msg.x, msg.y))
                {
                    board.reset(CHALLENGE_4);
                    currentState = PLAYING;
                    return;
                }
                else if (PtInRect(&backToModeButton, msg.x, msg.y))
                {
                    currentState = MODE_SELECTION;
                    return;
                }
            }
        }
        Sleep(1);// ����CPUռ��
    }
}

// �ر���Ϸ
void Game::close()
{
    closegraph();
}

// ��ʾ���˵�
void Game::showMainMenu()
{
    // ���Ʊ���
    settextstyle(48, 0, _T("����"), 0, 0, FW_BOLD, false, false, false);
    settextcolor(RGB(70, 130, 180));
    outtextxy(WIDTH / 2 - 75, 100, _T("������"));

    //���Ƹ�����
    settextstyle(24, 0, _T("����"));
    settextcolor(RGB(100, 100, 150));
    outtextxy(WIDTH / 2 - 85, 180, _T("Peg Solitaire"));

    // ���Ʋ˵�ѡ��
    settextstyle(36, 0, _T("����"));

    // ��ʼ��Ϸ��ť
    setfillcolor(hoveredOption == CLASSIC_MODE ? RGB(100, 200, 100) : RGB(180, 230, 100));
    fillrectangle(startButton.left, startButton.top, startButton.right, startButton.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(WIDTH / 2 - 80, 260, _T("��ʼ��Ϸ"));

    // ��Ϸ����ť
    setfillcolor(hoveredOption == GAME_RULES ? RGB(100, 180, 255) : RGB(180, 200, 255));
    fillrectangle(rulesButton.left, rulesButton.top, rulesButton.right, rulesButton.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(WIDTH / 2 - 80, 330, _T("��Ϸ����"));

    // �˳���Ϸ��ť
    setfillcolor(hoveredOption == EXIT_GAME ? RGB(255, 150, 150) : RGB(255, 180, 180));
    fillrectangle(exitButton.left, exitButton.top, exitButton.right, exitButton.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(WIDTH / 2 - 80, 400, _T("�˳���Ϸ"));
}

// ��ʾģʽѡ�����
void Game::showModeSelection()
{
    // ���Ʊ���
    settextstyle(36, 0, _T("����"), 0, 0, FW_BOLD, false, false, false);
    settextcolor(RGB(70, 130, 180));
    outtextxy(WIDTH / 2 - 100, 150, _T("ѡ����Ϸģʽ"));

    // ����ģʽѡ��
    settextstyle(36, 0, _T("����"));

    // ����ģʽ��ť
    setfillcolor(hoveredOption == CLASSIC_MODE ? RGB(100, 200, 100) : RGB(180, 230, 100));
    fillrectangle(classicButton.left, classicButton.top, classicButton.right, classicButton.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(WIDTH / 2 - 80, 260, _T("����ģʽ"));

    // �о�ģʽ��ť
    setfillcolor(hoveredOption == CHALLENGE_MODE ? RGB(100, 180, 255) : RGB(180, 200, 255));
    fillrectangle(challengeButton.left, challengeButton.top, challengeButton.right, challengeButton.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(WIDTH / 2 - 80, 330, _T("�о�ģʽ"));

    // ���ذ�ť
    setfillcolor(hoveredOption == EXIT_GAME ? RGB(255, 150, 150) : RGB(255, 180, 180));
    fillrectangle(backButton.left, backButton.top, backButton.right, backButton.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(WIDTH / 2 - 80, 400, _T("����"));
}

// ��ʾ��Ϸ����
void Game::showRules()
{
    settextstyle(36, 0, _T("����"), 0, 0, FW_BOLD, false, false, false);
    settextcolor(RGB(70, 130, 180));
    outtextxy(WIDTH / 2 - 150, 100, _T("��Ϸ����"));

    settextstyle(24, 0, _T("����"));
    settextcolor(RGB(80, 60, 30));

    int y = 180;
    outtextxy(100, y, _T("1. ����ֻ����ˮƽ��ֱ�����ƶ�"));
    y += 40;
    outtextxy(100, y, _T("2. ÿ���ƶ������������ڵ�һ������"));
    y += 40;
    outtextxy(100, y, _T("3. �����������ӻᱻ�Ƴ�"));
    y += 40;
    outtextxy(100, y, _T("4. Ŀ��λ�ñ���Ϊ��"));
    y += 40;
    outtextxy(100, y, _T("5. ��ϷĿ�꣺�Ƴ��������ӣ�ֻʣһ��"));
    y += 40;
    outtextxy(100, y, _T("6. ��ʣ�³���һ�������Ҿ������ƶ�����Ϸ����"));
    y += 40;
    outtextxy(100, y, _T("7. ������尴ť���Գ�����һ������"));
    y += 40;
    outtextxy(100, y, _T("8. �����ʾ��ť������ʾ���ܵ��ƶ�"));

    settextstyle(20, 0, _T("����"));
    settextcolor(RGB(100, 100, 150));
    outtextxy(WIDTH / 2 - 100, HEIGHT - 60, _T("�������λ�÷��ز˵�"));
}

// ��ʾ��Ϸ��������
void Game::showGameOver()
{
    settextstyle(48, 0, _T("����"), 0, 0, FW_BOLD, false, false, false);

    if (board.isWin())
    {
        settextcolor(RGB(40, 180, 40));
        outtextxy(WIDTH / 2 - 150, 100, _T("You win��"));
    }
    else
    {
        settextcolor(RGB(220, 40, 40));
        outtextxy(WIDTH / 2 - 150, 100, _T("You lose!"));
    }

    settextstyle(32, 0, _T("����"));
    settextcolor(RGB(80, 60, 30));
    TCHAR result[64];
    _stprintf_s(result, _T("ʣ������: %d"), board.getRemainingPieces());
    outtextxy(WIDTH / 2 - 100, 180, result);

    setfillcolor(RGB(255, 200, 100));
    fillrectangle(restartButton.left, restartButton.top, restartButton.right, restartButton.bottom);
    settextcolor(RGB(0, 0, 0));
    settextstyle(24, 0, _T("����"));
    outtextxy(restartButton.left + 10, restartButton.top + 10, _T("���¿�ʼ"));

    setfillcolor(RGB(180, 230, 100));
    fillrectangle(menuButton.left, menuButton.top, menuButton.right, menuButton.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(menuButton.left + 10, menuButton.top + 10, _T("���ز˵�"));
}

// ��ʾ��Ϸ����
void Game::playGame()
{
    board.draw();

    settextstyle(20, 0, _T("����"));

    setfillcolor(RGB(255, 200, 100));
    fillrectangle(restartButtonInGame.left, restartButtonInGame.top, restartButtonInGame.right, restartButtonInGame.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(restartButtonInGame.left + 10, restartButtonInGame.top + 5, _T("���¿�ʼ"));

    setfillcolor(RGB(180, 230, 100));
    fillrectangle(backButtonInGame.left, backButtonInGame.top, backButtonInGame.right, backButtonInGame.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(backButtonInGame.left + 10, backButtonInGame.top + 5, _T("���ز˵�"));

    setfillcolor(RGB(100, 180, 255));
    fillrectangle(undoButtonInGame.left, undoButtonInGame.top, undoButtonInGame.right, undoButtonInGame.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(undoButtonInGame.left + 10, undoButtonInGame.top + 5, _T("����"));

    setfillcolor(RGB(255, 165, 0));
    fillrectangle(hintButtonInGame.left, hintButtonInGame.top, hintButtonInGame.right, hintButtonInGame.bottom);
    settextcolor(RGB(0, 0, 0));
    outtextxy(hintButtonInGame.left + 10, hintButtonInGame.top + 5, _T("��ʾ"));
}

// ���Ʊ���ͼƬ
void Game::drawBackground() const
{
    putimage(0, 0, &backgroundImg);
}

// �����Ƿ��ھ�����
bool Game::PtInRect(const RECT* rect, int x, int y)
{
    return (x >= rect->left && x <= rect->right && y >= rect->top && y <= rect->bottom);
}