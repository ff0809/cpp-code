#ifndef GAME_H
#define GAME_H

#include "board.h"

//Game����Ϸ����
class Game
{
private:
    Board board;
    GameState currentState = MENU;
    MenuOption hoveredOption = NONE;
    GameMode selectedMode = CLASSIC;
    IMAGE backgroundImg; // ���뱳��ͼƬ����

    // ���˵���ť����ʼ��Ϸ�������˳���
    RECT startButton = { WIDTH / 2 - 100, 250, WIDTH / 2 + 100, 300 };
    RECT rulesButton = { WIDTH / 2 - 100, 320, WIDTH / 2 + 100, 370 };
    RECT exitButton = { WIDTH / 2 - 100, 390, WIDTH / 2 + 100, 440 };

    // ģʽѡ�񣨾����о֣���ť
    RECT classicButton = { WIDTH / 2 - 100, 250, WIDTH / 2 + 100, 300 };
    RECT challengeButton = { WIDTH / 2 - 100, 320, WIDTH / 2 + 100, 370 };
    RECT backButton = { WIDTH / 2 - 100, 390, WIDTH / 2 + 100, 440 };

    // �о�ѡ��ť
    RECT challenge1Button = { WIDTH / 2 - 220, 250, WIDTH / 2 - 20, 300 };
    RECT challenge2Button = { WIDTH / 2 + 20, 250, WIDTH / 2 + 220, 300 };
    RECT challenge3Button = { WIDTH / 2 - 220, 350, WIDTH / 2 - 20, 400 };
    RECT challenge4Button = { WIDTH / 2 + 20, 350, WIDTH / 2 + 220, 400 };
    RECT backToModeButton = { WIDTH / 2 - 100, 450, WIDTH / 2 + 100, 500 };

    // ��Ϸ������ť�����¿�ʼ�����ز˵���
    RECT restartButton = { WIDTH / 2 - 150, 350, WIDTH / 2 - 30, 400 };
    RECT menuButton = { WIDTH / 2 + 30, 350, WIDTH / 2 + 150, 400 };

    // ��Ϸ���水ť�����������ز˵������塢��ʾ��
    RECT restartButtonInGame = { WIDTH - 370, HEIGHT - 40, WIDTH - 270, HEIGHT - 10 };
    RECT backButtonInGame = { WIDTH - 260, HEIGHT - 40, WIDTH - 160, HEIGHT - 10 };
    RECT undoButtonInGame = { WIDTH - 150, HEIGHT - 40, WIDTH - 50, HEIGHT - 10 };
    RECT hintButtonInGame = { WIDTH - 480, HEIGHT - 40, WIDTH - 380, HEIGHT - 10 };

public:
    void init();
    void run();
    void close();

private:
    void handleMouseInput();
    void showChallengeSelection();
    void showMainMenu();
    void showModeSelection();
    void showRules();
    void showGameOver();
    void playGame();
    void drawBackground() const;
    bool PtInRect(const RECT* rect, int x, int y);
};

#endif // GAME_H