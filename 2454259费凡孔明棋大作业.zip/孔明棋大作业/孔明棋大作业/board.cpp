#include "board.h"

// ��ȡָ��λ��״̬
int Board::getState(int x, int y) const
{
    if (x >= 0 && x < 7 && y >= 0 && y < 7)
    {
        return state[x][y];
    }
    return -1;
}

// ��ȡʣ��������
int Board::getRemainingPieces() const
{
    return remainingPieces;
}

// ��ȡ��ǰ��Ϸģʽ
GameMode Board::getCurrentMode() const
{
    return currentMode;
}

// ѡ����ƶ�����
bool Board::selectOrMove(int mouseX, int mouseY)
{
    int col = (mouseX - OFFSET_X) / CELL_SIZE;
    int row = (mouseY - OFFSET_Y) / CELL_SIZE;

    if (row < 0 || row >= 7 || col < 0 || col >= 7 || layout[row][col] != 1)
    {
        return false;
    }

    if (state[row][col] == 1)
    {
        selectedX = row;
        selectedY = col;
        showHint = false;
        return true;
    }

    if (selectedX != -1 && selectedY != -1 && state[row][col] == 0)
    {
        if (tryMove(selectedX, selectedY, row, col))
        {
            MoveRecord record;
            record.fromX = selectedX;
            record.fromY = selectedY;
            record.toX = row;
            record.toY = col;
            record.midX = (selectedX + row) / 2;
            record.midY = (selectedY + col) / 2;
            history.push(record);

            state[selectedX][selectedY] = 0;
            state[row][col] = 1;
            remainingPieces--;
            state[record.midX][record.midY] = 0;

            // �ж��Ƿ������Ž�������
            if (followingOptimal && currentOptimalSolution && optimalStep < (int)currentOptimalSolution->size())
            {
                AIMoveHint move = (*currentOptimalSolution)[optimalStep];
                if (selectedX == move.fromX && selectedY == move.fromY && row == move.toX && col == move.toY)
                {
                    optimalStep++;
                }
                else     // �����ǰ�ƶ����������Ž����̣����ٸ���
                {
                    followingOptimal = false;
                }
            }

            selectedX = -1;
            selectedY = -1;
            showHint = false;
            return true;
        }
    }
    return false;
}

// �������
bool Board::undoMove()
{
    if (history.empty())
    {
        return false;
    }

    MoveRecord record = history.top();
    history.pop();

    state[record.fromX][record.fromY] = 1;
    state[record.toX][record.toY] = 0;
    state[record.midX][record.midY] = 1;

    remainingPieces++;

    selectedX = -1;
    selectedY = -1;
    showHint = false;

    // ����ʱ����optimalStep
    if (followingOptimal && optimalStep > 0)
    {
        optimalStep--;
    }
    // �����ʷ�͵�ǰ���Ž������Ƿ�һ��
    if (currentOptimalSolution && !history.empty())
    {
        std::stack<MoveRecord> tmpHistory = history;
        int step = (int)tmpHistory.size() - 1;
        bool stillOptimal = true;
        while (!tmpHistory.empty() && step >= 0)
        {
            MoveRecord rec = tmpHistory.top();
            tmpHistory.pop();
            if (step >= (int)currentOptimalSolution->size() ||
                rec.fromX != (*currentOptimalSolution)[step].fromX ||
                rec.fromY != (*currentOptimalSolution)[step].fromY ||
                rec.toX != (*currentOptimalSolution)[step].toX ||
                rec.toY != (*currentOptimalSolution)[step].toY)
            {
                stillOptimal = false;
                break;
            }
            step--;
        }
        followingOptimal = stillOptimal;
        if (stillOptimal)
            optimalStep = (int)history.size();
    }

    return true;
}

// ��������
void Board::reset(GameMode mode)
{
    currentMode = mode;

    switch (mode)
    {
    case CLASSIC:
        for (int i = 0; i < 7; i++)
            for (int j = 0; j < 7; j++)
                state[i][j] = (i == 3 && j == 3) ? 0 : layout[i][j];
        remainingPieces = 32;
        break;
    case CHALLENGE_1:
        for (int i = 0; i < 7; i++)
            for (int j = 0; j < 7; j++)
                state[i][j] = challenge1[i][j];
        remainingPieces = 7;
        break;
    case CHALLENGE_2:
        for (int i = 0; i < 7; i++)
            for (int j = 0; j < 7; j++)
                state[i][j] = challenge2[i][j];
        remainingPieces = 12;
        break;
    case CHALLENGE_3:
        for (int i = 0; i < 7; i++)
            for (int j = 0; j < 7; j++)
                state[i][j] = challenge3[i][j];
        remainingPieces = 16;
        break;
    case CHALLENGE_4:
        for (int i = 0; i < 7; i++)
            for (int j = 0; j < 7; j++)
                state[i][j] = challenge4[i][j];
        remainingPieces = 17;
        break;
    }

    selectedX = -1;
    selectedY = -1;
    while (!history.empty())
        history.pop();// �����ʷ��¼
    showHint = false;

    // ����/�л����Ž�����
    switch (mode)
    {
    case CLASSIC:
    {
        if (optimalSolutionClassic.empty()) // ������Ž�����Ϊ�գ����������Ž�
        {
            Board tmp = *this;
            std::unordered_set<std::string> visited;// ���ڼ�¼���ʹ��ľ���
            dfsSolve(tmp, optimalSolutionClassic, 60, &visited);// �������������DFS��������Ž�
        }
        currentOptimalSolution = &optimalSolutionClassic;// �л�������ģʽ�����Ž�����
        break;
    }
    case CHALLENGE_1:
    {
        if (optimalSolutionChallenge1.empty())
        {
            Board tmp = *this;
            std::unordered_set<std::string> visited;
            dfsSolve(tmp, optimalSolutionChallenge1, 30, &visited);
        }
        currentOptimalSolution = &optimalSolutionChallenge1;
        break;
    }
    case CHALLENGE_2:
    {
        if (optimalSolutionChallenge2.empty())
        {
            Board tmp = *this;
            std::unordered_set<std::string> visited;
            dfsSolve(tmp, optimalSolutionChallenge2, 30, &visited);
        }
        currentOptimalSolution = &optimalSolutionChallenge2;
        break;
    }
    case CHALLENGE_3:
    {
        if (optimalSolutionChallenge3.empty())
        {
            Board tmp = *this;
            std::unordered_set<std::string> visited;
            dfsSolve(tmp, optimalSolutionChallenge3, 30, &visited);
        }
        currentOptimalSolution = &optimalSolutionChallenge3;
        break;
    }
    case CHALLENGE_4:
    {
        if (optimalSolutionChallenge4.empty())
        {
            Board tmp = *this;
            std::unordered_set<std::string> visited;
            dfsSolve(tmp, optimalSolutionChallenge4, 30, &visited);
        }
        currentOptimalSolution = &optimalSolutionChallenge4;
        break;
    }
    default:
        currentOptimalSolution = nullptr;
        break;
    }
    optimalStep = 0;
    followingOptimal = (currentOptimalSolution && !currentOptimalSolution->empty());
}

// AI��ʾ
bool Board::getHint()
{
    // ����������Ž������ϣ�ֱ����ʾ���Ž����һ��
    if (followingOptimal && currentOptimalSolution && optimalStep < (int)currentOptimalSolution->size())
    {
        aiHint = (*currentOptimalSolution)[optimalStep];
        showHint = true;
        return true;
    }
    // ���򽵼�ΪA*
    solutionPath.clear();
    Board tmp = *this;
    std::unordered_set<std::string> visited;
    aiHint = findBestMoveUsingAStar(3);
    showHint = (aiHint.fromX != -1 && aiHint.fromY != -1);
    return showHint;
}

// ������뺯��
std::string Board::encodeBoard() const
{
    std::string s;
    for (int i = 0; i < 7; ++i)
        for (int j = 0; j < 7; ++j)
            s += (state[i][j] == 1 ? '1' : '0');// ������λ�ñ���Ϊ�ַ���
    return s;
}

// �л���ʾ��ʾ״̬
void Board::toggleHint()
{
    if (showHint)
    {
        showHint = false;// ����AI��ʾ
    }
    else
    {
        getHint();// ��ȡAI��ʾ
    }
}

// �������̺�����
void Board::draw() const
{
    // ��ʾ��ǰģʽ
    settextstyle(24, 0, _T("����"));
    settextcolor(RGB(80, 60, 30));

    const TCHAR* modeText = _T("����ģʽ");
    switch (currentMode)
    {
    case CHALLENGE_1: modeText = _T("�о�1"); break;
    case CHALLENGE_2: modeText = _T("�о�2"); break;
    case CHALLENGE_3: modeText = _T("�о�3"); break;
    case CHALLENGE_4: modeText = _T("�о�4"); break;
    }
    outtextxy(50, OFFSET_Y - 50, modeText);

    for (int i = 0; i < 7; i++)
    {
        for (int j = 0; j < 7; j++)
        {
            if (layout[i][j] == 1)
            {
                int x = OFFSET_X + j * CELL_SIZE;
                int y = OFFSET_Y + i * CELL_SIZE;

                setfillcolor(RGB(245, 230, 180));// ���̸�����ɫ
                fillrectangle(x, y, x + CELL_SIZE, y + CELL_SIZE);

                setlinecolor(RGB(180, 150, 90));// ���̸��ӱ߿���ɫ
                setlinestyle(PS_SOLID, 2);
                rectangle(x, y, x + CELL_SIZE, y + CELL_SIZE);

                if (state[i][j] == 1)
                {
                    if (i == selectedX && j == selectedY)
                    {
                        setfillcolor(RGB(40, 180, 40));//��ѡ�е�������ɫ
                        setlinecolor(RGB(0, 120, 0));
                    }
                    else if (showHint && i == aiHint.fromX && j == aiHint.fromY)
                    {
                        setfillcolor(RGB(255, 165, 0));//AI��ʾ��������ɫ 
                        setlinecolor(RGB(200, 120, 0));
                    }
                    else
                    {
                        setfillcolor(RGB(220, 40, 40));//δ��ѡ�е�������ɫ
                        setlinecolor(RGB(180, 0, 0));
                    }
                    fillcircle(x + CELL_SIZE / 2, y + CELL_SIZE / 2, PIECE_RADIUS);// ��������
                    circle(x + CELL_SIZE / 2, y + CELL_SIZE / 2, PIECE_RADIUS);
                }
                else if (showHint && i == aiHint.toX && j == aiHint.toY)
                {
                    setfillcolor(RGB(255, 255, 0));// AI��ʾ��Ŀ��λ����ɫ
                    fillcircle(x + CELL_SIZE / 2, y + CELL_SIZE / 2, 20);
                }
            }
        }
    }

    settextstyle(28, 0, _T("����"), 0, 0, FW_BOLD, false, false, false);
    settextcolor(RGB(220, 150, 126));
    TCHAR text[32];
    _stprintf_s(text, _T("ʣ�����ӣ�%d"), remainingPieces);
    int textWidth = textwidth(text);
    outtextxy((WIDTH - textWidth) / 2, OFFSET_Y - 50, text);
}

// �����ƶ�����
bool Board::tryMove(int fromX, int fromY, int toX, int toY) const
{
    if (state[toX][toY] != 0)
    {
        return false;
    }

    if (fromX == toX) //�������Ƿ����ƶ�
    {
        int distance = abs(fromY - toY);
        if (distance != 2)
        {
            return false;
        }

        int midY = (fromY + toY) / 2;
        if (state[fromX][midY] != 1)
        {
            return false;
        }
    }
    else if (fromY == toY)
    {
        int distance = abs(fromX - toX);
        if (distance != 2)
        {
            return false;
        }

        int midX = (fromX + toX) / 2;
        if (state[midX][fromY] != 1)
        {
            return false;
        }
    }
    else
    {
        return false;
    }

    return true;
}

// ��鵥���ƶ��Ƿ�Ϸ�
bool Board::canMove(int fromX, int fromY, int toX, int toY) const
{
    if (toX < 0 || toX >= 7 || toY < 0 || toY >= 7) return false;
    if (layout[toX][toY] != 1) return false;
    return tryMove(fromX, fromY, toX, toY);//�ٷ����������߼������ƶ��ж�
}

// �Ż������������ - ����ʽ����
int Board::evaluateBoard() const
{
    // ʣ������Խ��Խ�ã����ƶ�����Խ��Խ�ã�����Ȩ�ظ�
    int score = remainingPieces * 100;

    // ͳ�ƿ��ƶ�������
    int movable = 0;
    for (int i = 0; i < 7; ++i)
        for (int j = 0; j < 7; ++j)
            if (state[i][j] == 1)
                if (canMove(i, j, i - 2, j) || canMove(i, j, i + 2, j) ||
                    canMove(i, j, i, j - 2) || canMove(i, j, i, j + 2))
                    ++movable;
    score -= movable * 10;

    // ����Ȩ�أ��������ӿ������ģ�
    static const int centerWeight[7][7] =
    {
        {0,0,1,2,1,0,0},
        {0,1,2,3,2,1,0},
        {1,2,4,5,4,2,1},
        {2,3,5,8,5,3,2},
        {1,2,4,5,4,2,1},
        {0,1,2,3,2,1,0},
        {0,0,1,2,1,0,0}
    };
    int centerScore = 0;
    for (int i = 0; i < 7; ++i)
        for (int j = 0; j < 7; ++j)
            if (state[i][j] == 1)
                centerScore += centerWeight[i][j];
    score -= centerScore * 2;

    return score;
}

// ��ȡ���п��ܵ��ƶ�
vector<AIMoveHint> Board::getAllPossibleMoves() const
{
    vector<AIMoveHint> moves;

    for (int i = 0; i < 7; i++)
    {
        for (int j = 0; j < 7; j++)
        {
            if (state[i][j] == 1)
            {
                // ����ĸ�������ƶ�
                if (canMove(i, j, i - 2, j))
                {
                    moves.push_back({ i, j, i - 2, j });// �����ƶ���ʾ
                }
                if (canMove(i, j, i + 2, j))
                {
                    moves.push_back({ i, j, i + 2, j });
                }
                if (canMove(i, j, i, j - 2))
                {
                    moves.push_back({ i, j, i, j - 2 });
                }
                if (canMove(i, j, i, j + 2))
                {
                    moves.push_back({ i, j, i, j + 2 });
                }
            }
        }
    }

    return moves;
}

// ģ���ƶ����״̬
Board Board::simulateMove(const AIMoveHint& move) const
{
    Board newBoard = *this;

    newBoard.state[move.fromX][move.fromY] = 0;
    newBoard.state[move.toX][move.toY] = 1;
    newBoard.state[(move.fromX + move.toX) / 2][(move.fromY + move.toY) / 2] = 0;
    newBoard.remainingPieces--;

    return newBoard;
}

// ʹ��A*�㷨Ѱ������ƶ�
AIMoveHint Board::findBestMoveUsingAStar(int maxDepth) const
{
    vector<AIMoveHint> allMoves = getAllPossibleMoves();
    if (allMoves.empty()) return AIMoveHint(); // ������Ч��ʾ

    // ����ÿ�����ܵ��ƶ�
    vector<pair<int, AIMoveHint>> scoredMoves;

    for (const auto& move : allMoves)
    {
        Board newBoard = simulateMove(move);
        int score = aStarSearch(newBoard, maxDepth - 1);
        scoredMoves.emplace_back(score, move);
    }

    if (scoredMoves.empty()) return AIMoveHint();

    // ѡ��÷���͵��ƶ�������Խ��Խ�ã�
    auto bestMove = min_element(scoredMoves.begin(), scoredMoves.end(),
        [](const pair<int, AIMoveHint>& a, const pair<int, AIMoveHint>& b)
        {
            return a.first < b.first;
        });

    return bestMove->second;
}

// A*�����㷨
int Board::aStarSearch(const Board& board, int depth) const
{
    if (depth == 0 || board.isWin() || board.isLose())
    {
        return board.evaluateBoard();
    }

    vector<AIMoveHint> moves = board.getAllPossibleMoves();
    if (moves.empty())
    {
        return board.evaluateBoard();
    }

    int minScore = INT_MAX;

    for (const auto& move : moves)
    {
        Board newBoard = board.simulateMove(move);
        // ��֦������Ѿ�ʤ����ֱ�ӷ������ŷ���
        if (newBoard.isWin()) return newBoard.evaluateBoard();
        int score = aStarSearch(newBoard, depth - 1);
        if (score < minScore)
        {
            minScore = score;
        }
    }

    return minScore;
}

// dfsSolve����visited�����������ظ�������ͬ����
bool Board::dfsSolve(Board& board, std::vector<AIMoveHint>& path, int depthLimit, std::unordered_set<std::string>* visited)
{
    if (board.isWin()) return true;
    if (board.isLose() || depthLimit <= 0) return false;

    // �ж��Ƿ����ظ�����
    if (visited)
    {
        std::string code = board.encodeBoard();
        if (visited->count(code)) return false;
        visited->insert(code);
    }
    // �����ǰ�����Ѿ���·���У������ظ�����
    auto moves = board.getAllPossibleMoves();
    for (const auto& move : moves)
    {
        Board next = board.simulateMove(move);
        path.push_back(move);
        if (dfsSolve(next, path, depthLimit - 1, visited)) return true;
        path.pop_back();
    }
    return false;
}

// �ж��Ƿ�ʤ��
bool Board::isWin() const
{
    return remainingPieces == 1;
}

// �ж��Ƿ�ʧ��
bool Board::isLose() const
{
    if (remainingPieces <= 1) return false;

    for (int i = 0; i < 7; ++i)
    {
        for (int j = 0; j < 7; ++j)
        {
            if (state[i][j] == 1)
            {
                if (canMove(i, j, i - 2, j) || canMove(i, j, i + 2, j) || canMove(i, j, i, j - 2) || canMove(i, j, i, j + 2))
                {
                    return false;
                }
            }
        }
    }
    return true;
}