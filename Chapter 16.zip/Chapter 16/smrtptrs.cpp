#include <iostream>  
using namespace std;
class A {
private:
    int a;
public:
    void set(int x)
    {
        a = x;
    }
    void show()
    {
        cout << a << endl;
    }
};
class B :public A {
public:
    void fun()
    {
      //  a = 10;   //�����       
        set(10);  //���ɼ�ӷ���
    }
};
int main() {
    B b1;
    b1.set(15);
    b1.show();
    b1.fun();
    b1.show();
}