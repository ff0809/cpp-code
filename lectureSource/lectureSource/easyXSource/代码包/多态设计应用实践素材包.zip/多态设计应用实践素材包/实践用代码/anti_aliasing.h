#pragma once
#include <graphics.h>

// ������ࣺ���������
class LineDrawer {
protected:
    IMAGE* buffer = NULL;
public:
    void setBuffer(IMAGE* buffer);
    virtual void draw(int x1, int y1, int x2, int y2, COLORREF color, int thickness) = 0;
    virtual ~LineDrawer() = default;
};

// ������ࣺ�����Բ��
class CircleDrawer {
protected:
    IMAGE* buffer = NULL;
public:
    void setBuffer(IMAGE* buffer);
    virtual void draw(int center_x, int center_y, COLORREF color, int radius) = 0;
    virtual ~CircleDrawer() = default;
};

// �޿����ʵ��
class NoAA_Line : public LineDrawer {
public:
    //NoAA_Line(IMAGE* buffer) : AntiAliasedLine(buffer) {}
    void draw(int x1, int y1, int x2, int y2, COLORREF color, int thickness) override;
};

class NoAA_Circle : public CircleDrawer {
public:
    //NoAA_Circle(IMAGE* buffer) : AntiAliasedCircle(buffer) {}
    void draw(int center_x, int center_y, COLORREF color, int radius) override;
};

// SDF �����ʵ��
class SDF_Line : public LineDrawer {
public:
    //SDF_Line(IMAGE* buffer) : AntiAliasedLine(buffer) {}
    void draw(int x1, int y1, int x2, int y2, COLORREF color, int thickness) override;
};

class SDF_Circle : public CircleDrawer {
public:
    //SDF_Circle(IMAGE* buffer) : AntiAliasedCircle(buffer) {}
    void draw(int center_x, int center_y, COLORREF color, int radius) override;
};

// SSAA �����ʵ��
class SSAA_Line : public LineDrawer {
public:
    //SSAA_Line(IMAGE* buffer) : AntiAliasedLine(buffer) {}
    void draw(int x1, int y1, int x2, int y2, COLORREF color, int thickness) override;
};

class SSAA_Circle : public CircleDrawer {
public:
    //SSAA_Circle(IMAGE* buffer) : AntiAliasedCircle(buffer) {}
    void draw(int center_x, int center_y, COLORREF color, int radius) override;
};
