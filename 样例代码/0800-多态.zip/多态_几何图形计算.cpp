#include <iostream>
#include <cmath>
using namespace std;

class Shape {
public:
    // ���麯�� - �������
    virtual double area() const = 0;
    virtual double perimeter() const = 0;
    virtual void printInfo() const {
        cout << "ͼ����Ϣ��" << endl;
    }
    virtual ~Shape() = default;
};

class Circle : public Shape {
private:
    double radius;
public:
    Circle(double r) : radius(r) {}

    double area() const override {
        return 3.14159 * radius * radius;
    }

    double perimeter() const override {
        return 2 * 3.14159 * radius;
    }

    void printInfo() const override {
        cout << "Բ�� - �뾶: " << radius
            << ", ���: " << area()
            << ", �ܳ�: " << perimeter() << endl;
    }
};

class Rectangle : public Shape {
private:
    double width, height;
public:
    Rectangle(double w, double h) : width(w), height(h) {}

    double area() const override {
        return width * height;
    }

    double perimeter() const override {
        return 2 * (width + height);
    }

    void printInfo() const override {
        cout << "���� - ��: " << width << ", ��: " << height
            << ", ���: " << area()
            << ", �ܳ�: " << perimeter() << endl;
    }
};

// ��������ͼ�ε�ͨ�ú���
void processShapes(const Shape* shapes[], int count) {
    double totalArea = 0;
    double totalPerimeter = 0;

    for (int i = 0; i < count; i++) {
        shapes[i]->printInfo();  // ��̬����
        totalArea += shapes[i]->area();
        totalPerimeter += shapes[i]->perimeter();
    }

    cout << "\n�����: " << totalArea << endl;
    cout << "���ܳ�: " << totalPerimeter << endl;
}

int main() {
    Circle circle(5.0);
    Rectangle rectangle(4.0, 6.0);

    const Shape* shapes[] = { &circle, &rectangle };

    processShapes(shapes, 2);

    return 0;
}