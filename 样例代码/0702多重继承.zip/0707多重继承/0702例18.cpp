#include <iostream>  
using namespace std;
class A {
private:
    char* s;
public:
    int a;
    A()
    {
        s = new char[20];
    }
    ~A()
    {
        cout << "A����" << endl;
        delete s;
    }
};
class B :public A {
public:
    int b;
    ~B() { cout << "B����" << endl; }
};
int main()
{
    B b1;
    b1.a = 15;
    A a1(b1); //���ƹ���
}
